/**
 * Toto je dokumentačný komentár k triede Obdlznik, ktorá predstavuje vzorovú triedu pre 
 * študentov predmetu Informatika pre manažérov 2 a je určená na cvičenie č. 1.
 * Poznámka: Dokumentačný komentár sa používa buď pre triedu ako celok alebo pre jednotlivé metódy.
 * Je nepovinný a v kóde byť nemusí, nemá žiadny vplv na beh programu.
 * 
 * Trieda Obdlznik vychádza z podkladov Ing. Moniky Václavkovej, PhD.
 * 
 * @author doc. Ing. Marek Kvet, PhD.
 * @version 26.2.2020
 */
public class Obdlznik {
    /*
     * Toto je viacriadkový komentár. 
     * Najčastejšie sa používa na popis algoritmov alebo zložitejších častí tried. 
     * Pri kompilácií sa komentáre neberú do úvahy, slúžia predovšetkým programátorom
     * na lepšiu orientáciu v kóde a pochopenie algoritmov.
     * Poznámka: Kompilácia je preklad zdrojového kódu napisaného v programmovacom jazyku 
     * (v tomto prípade JAVA) do tzv. strojového kódu, ktorému rozumie procesor a na základe ktorého
     * vie vykonať jednotlivé inštrukcie. 
     */

    // Toto je jednoriadkový komentár, ktorý patrí medzi najčastejšie využívné formy poznámok v kóde.

    // Ako prvé sa v triede uvádzajú ATRIBÚTY, ktoré predstavujú vlastnosti objektov danej triedy.
    // Syntax: 1. kľúčové slovo private (atribúty sú súkromné - nepatria na verejnosť, nie sú dostupné zvonku)
    //         2. Dátový typ atribútu - int, double, String a podobne 
    //         3. názov atribútu
    //         4. Bodkočiarka
    private int sirka;
    private int vyska;

    // Trieda Obdlznik teda bude mať dva celočíselné atribúty.

    // Teraz nasledujú METÓDY, teda definícia služieb, ktoré objekty tejto triedy ponúkajú. 
    // De facto pôjde o špecifkáciu toho, na aké správy bude objekt reagovať a akým spôsobom.

    // Špeciálnou metódou, ktorá musí byť v každej triede definovaná, je tzv. konštruktor.
    // Konštruktor slúži na dve veci: 1. Vytvorenie inštancie, teda konkretneho objektu danej triedy
    //                                2. Inicializáciu, teda počiatočné nastavenie vlastností (atribútov)
    // Poznámka: Koľko má trťieda atribútov, toľko príkazov priradenia by sme mali v konštruktore použiť, 
    // aby sme nastavili všetky vlastnosti.
    // Konštuktor môže (nemusí) obsahovať parametre, ktorými sa nastavia atributy pri vzniku objektu.
    // Trieda môže mať viac konštruktorov, musia sa však líšiť počtom a typom parametrov!
    // V triede Obdlznik nadefinujeme dva konštruktory.

    // Podľa čoho spoznáte medzi metódami konštruktor(y)?
    // 1. Sú verejné - public
    // 2. Nemajú žiadny návratový typ (ani int, ani double, ani String, ani void, proste NIČ)
    // 3. Ich názov je totožný s názvom triedy. 

    /**
     * Bezparametrický konštruktor triedy Obdlznik
     * Všetky obdĺžniky vytvorené týmto konštruktorom budú mať rozmery 3x4.
     */
    public Obdlznik() {
        sirka = 3;
        vyska = 4;
    }

    /**
     * Parametrický konštruktor triedy Obdlznik
     * Všetky obdĺžniky vytvorené týmto konštruktorom budú mať rozmery podľa vstupných parametrov.
     * 
     * @param sirka je šírka obdĺžnika
     * @param vyska bude výška obdĺžnika
     */
    public Obdlznik(int sirka, int vyska) {
        /*
         * Pár poznámok k parametrickému konštruktoru:
         * 1. Všimnite si, že atribúty a parametre sa volajú rovnako. Principiálne s tým nie je problém,
         *    ale treba to nejako rozlíšiť. Pre prístup k atributu sa preto používa kľúčové slovo this.
         *    this.sirka je teda atribút, sirka je parameter. Priraďovacím príkazom this.sirka = sirka; 
         *    nastavíme atribútu hodnotu, ktorá vstúpi cez formálny parameter sirka. 
         *    Príkazy oddeľujeme bodkočiarkou.
         * 2. Na tomto mieste by sa zišlo nejaké ošetrenie vstupných parametrov. 
         *    Nastavovať rozmery obdĺžnika napríklad na (-10)x(-5) je nezmysel.
         *    Ako urobiť podmienku a ošetrenie hodnôt si ukážeme neskôr.
         */
        this.sirka = sirka;   
        this.vyska = vyska;
    }

    // Teraz už vieme, že objekty triedy Obdĺžnik majú dva atribúty a máme nástroj,
    // pomocou ktorého vieme objekty vytvárať (konštruktory). 
    
    // Zostávajú nám ešte služby - reakcie na správy, resp. METÓDY 
    // Každá metóda má hlavičku a telo. Syntax hlavičky je nasledovná:
    // 1. Kľúčové slovo public - metódy sú verejné, inak by sme ich nemohli volať zvonku
    // 2. Návratový typ:
    //    a, int - celé číslo
    //    b, double - reálne číslo s desatinnou čiarkou (bodkou)
    //    c, String - reťazec znakov, text
    //    d, void - nič (metóda len vykoná príkazy a skončí). Takáto metóda najčastejšie niečo 
    //       vypisuje, zobrazuje, kreslí, nastavuje a podobne.
    // 3. Názov metódy
    // 4. Parametre - sú nepovinné, avšak zátvorky () musíme uvádzať vždy!
    
    /**
     * Metóda na výpočet obsahu obdĺžnika
     * 
     * @return obsah obdĺžnika
     */
    public int dajObsah() {
        int pomocna;             // deklarácia pomocnej lokálnej premennej
        pomocna = sirka * vyska; // samotný výpočet obshu
        return pomocna;          // návrat hodnoty lokálnej premennej - výsledok metódy (funkcie)
    }
    
    /**
     * Metóda na výpočet obvodu obdĺžnika
     * 
     * @return obvod obdĺžnika
     */
    public int dajObvod() {
        return 2 * (sirka + vyska);
    }
    
    /**
     * Metóda na výpočet veľkosti uhlopriečky obdĺžnika
     * 
     * @return veľkosť uhlopriečky obdĺžnika
     */
     public double dajUhlopriecku() {
        int pomocna = (sirka * sirka) + (vyska * vyska);
        return Math.sqrt(pomocna); // Volanie metody sqrt abstraktnej triedy Math (odmocnina)
    }
    
    // Úlohy na doma 
    // (na precvičenie - táto domáca úloha sa nebude kontrolovať a nie je bodovo hodnotená!)
    
    // 1. Doplňte do triedy Obdlznik tzv. setter, teda metódu, pomocou ktorej zmeníte jeden 
    //    z atribútov (napríklad šírku).
    // 2. Doplňte do triedy Obdlznik tzv. getter, teda metódu, ktorá sprístupní hodnotu Vami zvoleného 
    //    atribútu navonok (atribúty sú súkromné, zvonku ich nevidno a jediný spôsob, ako vrátiť hodnotu,
    //    je použiť metódu).
    // 3. Skúste si navrhnúť a implementovať vlastnú triedu s pár atribútmi a metódami a otestujte ju
    //    na niekoľkých objektoch.
}
