public class BankovyUcet {
    private String nazovUctu;
    private String PIN;
    private double zostatok;
    private double urokovaSadzba;
    private int pocetTransakcii;
    private double[] transakcie;

    public BankovyUcet() {
        //this.nazovUctu = "MK";
        //this.PIN = "0000";
        //this.zostatok = 0;
        //this.urokovaSadzba = 1; // v percentach
        //this.transakcie = new double[100];
        //this.pocetTransakcii = 0;

        // Tychto 5 riadkov sa da nahradit volanim parametrickeho konstruktora.
        this("MK", "0000", 0.0, 1.0, 100);
    }

    public BankovyUcet(String nazov, String PIN, double pociatocnyVklad, double urok, int maxPocetTransakcii) {
        this.nazovUctu = nazov;
        this.PIN = PIN;
        this.zostatok = pociatocnyVklad;
        this.urokovaSadzba = urok;
        this.transakcie = new double[maxPocetTransakcii];
        this.pocetTransakcii = 0;
    }

    private boolean overHeslo(String heslo) {
        return heslo.equals(this.PIN);
    }

    public double getZostatok() {
        return this.zostatok;
    }

    public void vypisZuctu() {
        System.out.println("Nazov uctu: " + this.nazovUctu);
        System.out.println("Aktualny zostatok: " + this.zostatok);
        System.out.println("Urokova sadzba: " + this.urokovaSadzba);

        if (this.pocetTransakcii > 0) {
            System.out.println("Pocet transakcii: " + this.pocetTransakcii);
            for(int i = 0; i < this.pocetTransakcii; i++) {
                if (this.transakcie[i] > 0)
                    System.out.println("Vklad " + this.transakcie[i]);
                else 
                    System.out.println("Vyber " + (-this.transakcie[i]));
            }
        } else {
            System.out.println("Na ucte nebola vykonana ziadna transakcia.");
        }
    }

    public double vypocitajPriemernyVklad() {
        double priemer = 0;
        int pocet = 0;

        for(int i = 0; i < this.pocetTransakcii; i++) {
            if (this.transakcie[i] > 0) {
                pocet++;
                priemer = priemer + this.transakcie[i];
            }
        }

        if (pocet > 0) {
            priemer = priemer / pocet;
            return priemer;
        }
        else
            return 0;
    } 

    public void vlozNaUcet(double ciastka) {
        if (ciastka > 0) {
            if (this.pocetTransakcii < this.transakcie.length) {
                this.zostatok = this.zostatok + ciastka;
                this.transakcie[this.pocetTransakcii] = ciastka;
                this.pocetTransakcii++;
            }
            else 
                System.out.println("Pole transakcii je plne!");
        } else 
            System.out.println("Vkladana ciastka musi byt kladna!");
    }

    public void vyberZuctu(double ciastka, String kod) {
        if ((ciastka > 0) && (ciastka <= this.zostatok)) {
            if (this.overHeslo(kod)) {            
                if (this.pocetTransakcii < this.transakcie.length) {
                    this.zostatok = this.zostatok - ciastka;
                    this.transakcie[this.pocetTransakcii] = -ciastka;
                    this.pocetTransakcii++;
                }
                else 
                    System.out.println("Pole transakcii je plne!");
            } else
                System.out.println("Overenie PIN bolo neuspesne!");
        } else
            System.out.println("Zadali ste nespravnu ciastku!");
    }

    public void pripisUrok() {
        this.zostatok = this.zostatok * ((100 + this.urokovaSadzba) / 100);
    }
}