public class Klient{
    private String meno;
    private String priezvisko;
    private BankovyUcet bankovyUcet;

    public Klient(){
        this.meno = "Marek";
        this.priezvisko = "Kvet";
        this.bankovyUcet = null;
    }

    public String getMeno(){
        return this.meno;
    }

    public String getPriezvisko(){
        return this.priezvisko;
    }

    public BankovyUcet getBankovyUcet(){
        return this.bankovyUcet; 
    }

    public void setMeno(String noveMeno){
        this.meno = noveMeno;
    }

    public void setPriezvisko(String novePriezvisko){
        this.priezvisko = novePriezvisko;
    }

    public void setBankovyUcet(BankovyUcet novyUcet){
        this.bankovyUcet = novyUcet;
    }
}
