public class BankovyUcet {
    private String nazovUctu;
    private String PIN;
    private double zostatok;
    private double urokovaSadzba;
    private PoleDouble transakcie;

    public BankovyUcet() {
        //this.nazovUctu = "MK";
        //this.PIN = "0000";
        //this.zostatok = 0;
        //this.urokovaSadzba = 1; // v percentach
        //this.transakcie = new PoleDouble(100);

        // Tychto 5 riadkov sa da nahradit volanim parametrickeho konstruktora.
        this("MK", "0000", 0.0, 1.0, 100);
    }

    public BankovyUcet(String nazov, String PIN, double pociatocnyVklad, double urok, int maxPocetTransakcii) {
        this.nazovUctu = nazov;
        this.PIN = PIN;
        this.zostatok = pociatocnyVklad;
        this.urokovaSadzba = urok;
        this.transakcie = new PoleDouble(maxPocetTransakcii);
    }

    private boolean overHeslo(String heslo) {
        return heslo.equals(this.PIN);
    }

    public double getZostatok() {
        return this.zostatok;
    }

    public void vypisZuctu() {
        System.out.println("Nazov uctu: " + this.nazovUctu);
        System.out.println("Aktualny zostatok: " + this.zostatok);
        System.out.println("Urokova sadzba: " + this.urokovaSadzba);

        System.out.println("Transakcie:");
        this.transakcie.vypisPrvkyPola();
    }

    public double vypocitajPriemernyVklad() {
        return this.transakcie.vypocitajPriemernyVklad();
    } 

    public void vlozNaUcet(double ciastka) {
        if (ciastka > 0) {
            if (this.transakcie.moznoPridatPrvokDoPola()) {
                this.zostatok = this.zostatok + ciastka;
                this.transakcie.vlozNovyPrvokDoPola(ciastka);
            }
            else 
                System.out.println("Pole transakcii je plne!");
        } else 
            System.out.println("Vkladana ciastka musi byt kladna!");
    }

    public void vyberZuctu(double ciastka, String kod) {
        if ((ciastka > 0) && (ciastka <= this.zostatok)) {
            if (this.overHeslo(kod)) {            
                if (this.transakcie.moznoPridatPrvokDoPola()) {
                    this.zostatok = this.zostatok - ciastka;
                    this.transakcie.vlozNovyPrvokDoPola(-ciastka);
                }
                else 
                    System.out.println("Pole transakcii je plne!");
            } else
                System.out.println("Overenie PIN bolo neuspesne!");
        } else
            System.out.println("Zadali ste nespravnu ciastku!");
    }

    public void pripisUrok() {
        this.zostatok = this.zostatok * ((100 + this.urokovaSadzba) / 100);
    }
}