public class PoleDouble {
    private int pocetPrvkov;
    private double[] hodnoty;

    public PoleDouble(int kapacita) {
        if (kapacita > 0)
            this.hodnoty = new double[kapacita];
        else
            this.hodnoty = new double[100];

        this.pocetPrvkov = 0;
    }

    public int getPocetPrvkov() {
        return this.pocetPrvkov;
    }

    public void vypisPrvkyPola() {
        if (this.pocetPrvkov > 0) {
            System.out.println("Pocet prvkov pola: " + this.pocetPrvkov);
            for(int i = 0; i < this.pocetPrvkov; i++) {
                if (this.hodnoty[i] > 0)
                    System.out.println("Vklad " + this.hodnoty[i]);
                else 
                    System.out.println("Vyber " + (-this.hodnoty[i]));
            }
        } else {
            System.out.println("Pole neobsahuje ziadne prvky.");
        }   
    }

    public double vypocitajPriemernyVklad() {
        double priemer = 0;
        int pocet = 0;

        for(int i = 0; i < this.pocetPrvkov; i++) {
            if (this.hodnoty[i] > 0) {
                pocet++;
                priemer = priemer + this.hodnoty[i];
            }
        }

        if (pocet > 0) {
            priemer = priemer / pocet;
            return priemer;
        }
        else
            return 0;
    } 

    public boolean moznoPridatPrvokDoPola() {
        return (this.pocetPrvkov < this.hodnoty.length);
    }

    public void vlozNovyPrvokDoPola(double cislo) {
        this.hodnoty[this.pocetPrvkov] = cislo;
        this.pocetPrvkov++;
    }
}
