public class AutomatMHD {
    private int cenaListka;
    private int vlozenaCiastka;
    private int trzba;

    public AutomatMHD(int cenaListka) {
        this.cenaListka = cenaListka;
        this.vlozenaCiastka = 0;
        this.trzba = 0;
    }
    
    public int getCenaListka() {
        return this.cenaListka;
    }
    
    public int getVlozenaCiastka() {
        return this.vlozenaCiastka;
    }
    
    public void vlozMincu(int hodnotaMince) {
        this.vlozenaCiastka = this.vlozenaCiastka + hodnotaMince;
    }
    
    public void tlacListok() {
        // Tlac listka do okna konzoly
        System.out.println("*************************");
        System.out.println("* Skolska linka FRI");
        System.out.println("* Cestovny listok");
        System.out.print("* cena ");
        System.out.print(this.cenaListka);
        System.out.println(" centov");
        System.out.println("*************************");
        System.out.println();
        
        this.trzba = this.trzba + this.vlozenaCiastka;
        this.vlozenaCiastka = 0;
    }
}
