import java.util.Calendar; // Použitie externej triedy Calendar (prilinkovanie triedy Calendar z knižnice, resp. balíčka java.util)

public class Osoba {
    private String meno;
    private String priezvisko;
    private int rokNarodenia;
    private boolean narokNaVlakyZadarmo;

    public Osoba(String meno, String priezvisko, int rokNarodenia, boolean narok) {
        this.meno = meno;
        this.priezvisko = priezvisko;
        this.rokNarodenia = rokNarodenia;
        this.narokNaVlakyZadarmo = narok;
    }

    public String getMenoApriezvisko() {
        return this.meno + " " + this.priezvisko; 
    }

    // Toto je súkromná správa, ktorú môže objekt poslať len sám sebe, zvonka ju poslať nemožno!
    private int zistiAktualnyRok() {
        return Calendar.getInstance().get(Calendar.YEAR); // Z aktuálneho dátumu sa cez výstup metódy zistiAktualnyRok() vráti rok.
    }

    public int getVek() {
        return this.zistiAktualnyRok() - this.rokNarodenia;
    }

    public boolean getNarokNaVlakyZadarmo() {
        return this.narokNaVlakyZadarmo;
    }

    public void vypisInfo() {
        System.out.println("Som objekt triedy Osoba");
        System.out.println("Meno a priezvisko: " + getMenoApriezvisko());
        System.out.println("Vek: " + getVek());
        if (getNarokNaVlakyZadarmo() == true)
            System.out.println("Vlaky zadarmo: áno");
        else
            System.out.println("Vlaky zadarmo: nie");
    }
}
