/**
 * Trieda Aplikacia je určená na testovanie základných funkcií aplikácie.
 * Obsahuje jedinú metodu main.
 * 
 * @author Marek Kvet
 * @version 20.11.2017
 */
public class Aplikacia {
    public static void main(String[] args)
    {
        OdpadkovyKos kontajner = new OdpadkovyKos(5);
        kontajner.prihodOdpadok(new Odpad("kov", 2.5));
        kontajner.prihodOdpadok(new Odpad("papier", 5));
        kontajner.prihodOdpadok(new Odpad("stavebny odpad", 60));
        kontajner.prihodOdpadok(new Odpad("", 1.5));
        kontajner.vypisZoznamOdpadkovVkosi();
        kontajner.vyprazdniKontajner();
        kontajner.vypisZoznamOdpadkovVkosi();
    }
}
