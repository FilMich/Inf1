/**
 * Trieda Odpad je určená pre individuálny odpad. Bude mať dva
 * atribúty:
 * 1. textový popis - tu sa očakáva niečo ako "Kov", "Papier", "Odpad z domácnosti" apod.
 * 2. číselný objem. 
 * Okrem toho bude poskytovať svoj stav v textovej forme.
 * 
 * @author Marek Kvet
 * @version 20.11.2017
 */
public class Odpad {
    // Charakteristicke vlastnosti odpadu - ATRIBUTY
    private String aPopis;
    private double aObjem;
    
    /**
     * Parametrický konštruktor triedy Odpad bude slúžiť na vytvorenie inštancií s používateľom
     * definovanými hodnotami atribútov.
     */
    public Odpad(String paString, double paObjem) {
        this.aPopis = paString;
        this.aObjem = paObjem;
    }
        
    /**
     * Metóda dajObjem sprístupní hodnotu atributu aObjem.
     */
    public double dajObjem() {
        return this.aObjem;
    }

    /**
     * Metóda toString sprístupní hodnoty atributov v textovej forme.
     */
    public String toString() {
        return "Odpad má objem " + this.aObjem + " a popis: " + this.aPopis;
    }
}
