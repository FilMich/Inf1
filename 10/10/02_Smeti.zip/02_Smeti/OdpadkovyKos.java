/**
 * Trieda OdpadkovyKos je určená pre kontajner odpadkov. Tento kontajner bude reprezentovaný
 * statickým poľom (statickým znamená, že má presne a pevne definovanú veľkosť - maximálny počet prvkov) 
 * objektov typu Odpad. S týmto poľom sa budú vykonávať základné operácie ako vloženie nového odpadku,
 * prezeranie aktuálneho stavu kontajnera, vyprázdnenie a podobne.
 * 
 * @author Marek Kvet
 * @version 20.11.2017
 */
public class OdpadkovyKos {
    private static double maximalnyObjem = 100.0; // Objem kontajnera (toto obmedzenie sa bude kontrolovat pri kazdom pokuse
                                                  // o vlozenie noveho odpadku)
    private int aAktualnyPocetOdpadkov;           // Aktualny pocet prvkov v kontajneri
    private double aAktualnyObjemOdpadkov;        // Aktualnmy objem odpadkov v kosi    
    private int aMaximalnyPocetOdpadkov;          // Maximalny pocet prvkov v kontajneri - toto je vlastne kapacita kontajnera
                                                  // z pohladu poctu smeti (nie ich objemu)  
    private Odpad[] aSmeti;                       // Pole odpadkov (vytvori sa v konstruktore,
                                                  // pricom maximalny pocet prvkov pola bude parametrom konstruktora.
    /**
     * Bezparametrický konštruktor triedy OdpadkovyKos bude slúžiť na vytvorenie inštancií s vopred 
     * definovanými hodnotami atribútov.
     * V tomto prípade sa vytvorí pole o veľkosti 10 prvkov a prehľad o vykonanych operaciach 
     * s maximalne 30 záznamami.
     */
    public OdpadkovyKos() {
        this.aAktualnyPocetOdpadkov = 0;                       // nastavenie aktualneho poctu odpadkov
        this.aAktualnyObjemOdpadkov = 0;                       // nastavenie aktualneho objemu odpadkov
        this.aMaximalnyPocetOdpadkov = 10;                     // nastavenie maximalneho poctu odpadkov
        this.aSmeti = new Odpad[this.aMaximalnyPocetOdpadkov]; // vytvorenie pola na odpadky
    }

    /**
     * Parametrický konštruktor triedy OdpadkovyKos bude slúžiť na vytvorenie inštancií 
     * s používateľom definovanými hodnotami atribútov.
     */
    public OdpadkovyKos(int paKapacitaKontajnera) {
        this.aAktualnyPocetOdpadkov = 0;                       // nastavenie aktualneho poctu odpadkov
        this.aAktualnyObjemOdpadkov = 0;                       // nastavenie aktualneho objemu odpadkov
        this.aMaximalnyPocetOdpadkov = paKapacitaKontajnera;   // nastavenie maximalneho poctu odpadkov
        this.aSmeti = new Odpad[this.aMaximalnyPocetOdpadkov]; // vytvorenie pola na odpadky
    }

    /**
     * Metóda vypisZoznamOdpadkovVkosi vypíše na obrazovku aktuálny stav kontajnera, 
     * pričom ak je v kontajneri aspoň jeden odpad,
     * vypíše sa celý zoznam odpadkov s informáciami o nich.
     */
    public void vypisZoznamOdpadkovVkosi() {
        // Ak je kontajner prazdny, vypise sa o tom informacia.
        if (this.aAktualnyPocetOdpadkov == 0) {
            System.out.println("Kontajner je prazdny.");
        } else {
            System.out.println("Zoznam odpadkov:");
            for(int i = 0; i < aAktualnyPocetOdpadkov; i++) {
                System.out.println(i + ". " + this.aSmeti[i].toString()); 
            }
        }
    }

    /**
     * Metóda prihodOdpadok slúži na vloženie nového odpadku do kontajnera, 
     * pričom treba skontrolovať, či kontajner nie je plný (z pohľadu kapacity)
     * a tiež, či sa nový odpad vzhľadom na svoj objem zmestí do kontajnera.
     */
    public void prihodOdpadok(Odpad paNovyOdpadok) {
        // Najprv sa kontroluje pocet prvkov v poli. Ak je pole plne, nic sa nevlozi.
        if (this.aAktualnyPocetOdpadkov == this.aMaximalnyPocetOdpadkov) {
            System.out.println("Kontajner je plny, prosim, vyprazdnite ho! Novy odpad nie je mozne vlozit!");
        } else {
            // Z pohladu kapacity kontajnera by sa odpad mohol vlozit, treba vsak skontrolovat limit na objem.
            if (paNovyOdpadok.dajObjem() + aAktualnyObjemOdpadkov > this.maximalnyObjem) {
                System.out.println("Vlozenie tohto odpadku by prekrocilo maximalny povoleny objem kontajnera!");
            } else {
                this.aSmeti[aAktualnyPocetOdpadkov] = paNovyOdpadok;
                this.aAktualnyPocetOdpadkov++;
            }
        }
    }

    /**
     * Metóda vyprazdniKontajner odstráni všetky prvky z poľa.
     */
    public void vyprazdniKontajner() {
        this.aAktualnyPocetOdpadkov = 0;
    }
}
