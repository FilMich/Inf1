public class Suradnice {
    private int X;
    private int Y;
    
    public Suradnice(int X, int Y) {
        this.X = X;
        this.Y = Y;
    }
    
    public int getX() {
        return this.X;
    }
    
    public int getY() {
        return this.Y;
    }
}
