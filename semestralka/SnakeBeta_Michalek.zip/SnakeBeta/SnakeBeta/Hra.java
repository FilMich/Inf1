import java.util.Random;

public class Hra {
    private Random generator;
    private Ovladanie ovladanie;
    private Blok blok;
    private Manazer manazer;
    private Hadik hadik;
    private int smer;
    public Hra() {
        this.manazer = new Manazer();
        this.ovladanie = new Ovladanie();
        this.generator = new Random();
        this.hadik = new Hadik(20, 20);
        this.hadik.nakresli();
    }
    
}
