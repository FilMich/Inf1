public class Hlavna {
    //Aby sa nedala spravit instancia
    private Hlavna() {
    }
    
    
    public static void main(String[] args) {
        new Tetris().spusti();
    }
}
