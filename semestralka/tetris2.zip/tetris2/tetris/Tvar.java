public enum Tvar {
    I,
    O,
    S,
    Z,
    L,
    J;
}
