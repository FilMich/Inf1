public class Suradnice {
    private int X;
    private int Y;
    private int indexX;
    private int indexY;
    public Suradnice(int X, int Y, int indexX, int indexY) {
        this.X = X;
        this.Y = Y;
        this.indexX = indexX;
        this.indexY = indexY;
    }
    
    public int getX() {
        return this.X;
    }
    
    public int getY() {
        return this.Y;
    }
    
    public int getIndexX() {
        return this.indexX;
    }
    
    public int getIndexY() {
        return this.indexY;
    }
}
