import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Hadik {
    private ArrayList<Blok> telo;
    private Obrazok obrazok;
    private Blok blok;
    private Suradnice[][] suradnice;
    private int polohaX;
    private int polohaY;
    private HraciaPlocha hraciaPlocha;
    private Smer smer;
    public Hadik(Suradnice[][] suradnice, HraciaPlocha hraciaPlocha) {
        
        this.telo = new ArrayList<Blok>();
        this.suradnice = suradnice;
        this.polohaX = 4;
        this.polohaY = 4;
        this.hraciaPlocha = hraciaPlocha;
        //nakresli prve tri vodorovne stvorce hada
        int pixelX = this.suradnice[this.polohaY][this.polohaX].getX();
        int pixelY = this.suradnice[this.polohaY][this.polohaX].getY();
        this.telo.add(new Blok(pixelX, pixelY, "hlava", this.polohaX, this.polohaY));
        this.posunHadovuHlavu(Smer.DOPRAVA);
        this.posunHadovuHlavu(Smer.DOPRAVA);
    }
    
    public ArrayList<Blok> getTelo() {
        return this.telo;
    }
    
    public void posunHadovuHlavu(Smer smer) {
        switch(smer) {
            case HORE:
                this.polohaY--;
                break;
            case DOLE:
                this.polohaY++;
                break;
            case DOPRAVA:
                this.polohaX++;
                break;
            case DOLAVA:
                this.polohaX--;
                break;
        }
        int pixelX = this.suradnice[this.polohaY][this.polohaX].getX();
        int pixelY = this.suradnice[this.polohaY][this.polohaX].getY();
        this.telo.add(new Blok(pixelX, pixelY, "telo", this.polohaX, this.polohaY));
        this.smer = smer;
    }
    
    public Smer getSmer() {
        return this.smer;
    }
    
    public void posunHadovChvost() {
        this.telo.get(0).zmaz();
        this.telo.remove(0);
    }
    
    public void nakresli() {
        for (Blok b: this.telo) {
            b.getObrazok().zobraz();
        }
    }
    
    public int getPolohuX() {
        return this.polohaX;
    }
    
    public int getPolohuY() {
        return this.polohaY;
    }
    
    public void zvacsiSa() {
        this.posunHadovuHlavu(this.smer);
    }
    
    public void skontrolujHada() {
        for (Blok b: this.telo) {
           if (this.polohaX != this.telo.get(this.telo.size() - 1).getPolohuX() && this.polohaY != this.telo.get(this.telo.size() - 1).getPolohuY()) {
               if (this.polohaX == b.getPolohuX() && this.polohaY == b.getPolohuY()) {
                   JOptionPane.showMessageDialog(null, "Koniec hry");
                }
            } /*if (this.polohaX == this.telo.get(this.telo.size()).getPolohuX() && this.polohaY == this.telo.get(this.telo.size()).getPolohuY()) {
                
            } else if (b.getPolohuX() == this.polohaX && b.getPolohuY() == this.polohaY) {
                    JOptionPane.showMessageDialog(null, "Koniec hry");
                }*/
            }
    }
    
    public void vypisHada() {
        for (Blok b: this.telo) {
            System.out.print("[" + b.getPolohuX() + "," + b.getPolohuY() + "] ");
        }
        System.out.print(this.telo.size());
        System.out.print("[" + this.polohaX + "," + this.polohaY + "]");
        System.out.print("[" + this.telo.get(this.telo.size() - 1).getPolohuX() + "," + this.telo.get(this.telo.size() - 1).getPolohuY() + "]");
    }
}
