import java.util.Random;
import java.util.ArrayList;
/**
 * Write a description of class Jablko here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jablko {
    private Random generator;
    private Obrazok obrazok;
    private Blok blok;
    private Suradnice[][] suradnice;
    private int polohaX;
    private int polohaY;
    private HraciaPlocha hraciaPlocha;
    private Hadik hadik;
    private ArrayList<Blok> telo;
    public Jablko(Suradnice[][] suradnice, Hadik hadik, ArrayList<Blok> telo) {
        this.telo = telo;
        this.hadik = hadik;
        this.generator = new Random();
        this.suradnice = suradnice;
        this.polohaX = this.generator.nextInt(18) + 1;
        this.polohaY = this.generator.nextInt(18) + 1;
        this.skontroluj();
        int pixelX = this.suradnice[this.polohaY][this.polohaX].getX();
        int pixelY = this.suradnice[this.polohaY][this.polohaX].getY();
        this.blok = new Blok(pixelX, pixelY, "jedlo", this.polohaX, this.polohaY);
    }
    
    public int getPolohuX() {
        return this.polohaX;
    }
    
    public int getPolohuY() {
        return this.polohaY;
    }
    
    public void zmazJ() {
        this.blok.getObrazok().zmaz();
    }
    
    public void skontroluj() {
        for (Blok b: this.telo) {
            if (b.getPolohuX() == this.polohaX && b.getPolohuY() == this.polohaY) {
                this.polohaX = this.generator.nextInt(18) + 1;
                this.polohaY = this.generator.nextInt(18) + 1;
                this.skontroluj();
            }
        }
    }
}
