public class Blok {
    private int suradnicaX;
    private int suradnicaY;
    private String typBloku;
    private Obrazok obrazok;
    private int polohaX;
    private int polohaY;
    public Blok(int suradnicaX, int suradnicaY, String typBloku, int polohaX, int polohaY) {
        this.suradnicaX = suradnicaX;
        this.suradnicaY = suradnicaY;
        this.polohaX = polohaX;
        this.polohaY = polohaY;
        this.typBloku = typBloku;
        if (typBloku.equals("jedlo")) {
            this.obrazok = new Obrazok("pics\\jablko.png");
        } else {
            this.obrazok = new Obrazok("pics\\stvorec.png");
        }
        this.obrazok.zmenPolohu(this.suradnicaX, this.suradnicaY);
        this.nakresli();
    }
    
    public Obrazok getObrazok() {
        return this.obrazok;
    }
    
    public int getX() {
        return this.suradnicaX;
    }
    
    public int getY() {
        return this.suradnicaY;
    }
    
    public int getPolohuX() {
        return this.polohaX;
    }
    
    public int getPolohuY() {
        return this.polohaY;
    }
    
    public String getTyp() {
        return this.typBloku;
    }
    
    public void setX(int x) {
        this.suradnicaX = x;
    }
    
    public void setY(int y) {
        this.suradnicaY = y;
    }
    
    public void nakresli() {
        this.obrazok.zobraz();
    }
    
    public void zmaz() {
        this.obrazok.zmaz();
    }
    
}
