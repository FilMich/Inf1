public class Ovladanie {
    private Hadik hadik;
    private Manazer manazer;
    private Smer smer;
    private int pocetTikov = 0;
    private Hra hra;
    private Jablko jablko;
    private HraciaPlocha hraciaPlocha;
    public Ovladanie(Hadik hadik, Smer smer, Hra hra) {
        this.hra = hra;
        this.hadik = hadik;
        this.smer = smer;
        this.manazer = new Manazer();
        this.manazer.spravujObjekt(this);
    }
        
    public void posunVpravo() {
        this.smer = Smer.otocDoprava(this.smer);
    }
    
    public void posunVlavo() {
        this.smer = Smer.otocDolava(this.smer);    
    }
    
    public void posunHore() {
       this.smer = Smer.otocHore(this.smer);
    }
    
    public void posunDole() {
       this.smer = Smer.otocDole(this.smer);
    }
    
    public void tik() {
        if(this.pocetTikov > 0.5) {
            this.hra.koliziaHranice();
            if (this.hra.koliziaJablko() == false) {
                this.hadik.posunHadovuHlavu(this.smer);
                this.hadik.posunHadovChvost();
            }
            this.hadik.skontrolujHada();
            this.pocetTikov = 0;
        }
        this.pocetTikov++;
    }
}
