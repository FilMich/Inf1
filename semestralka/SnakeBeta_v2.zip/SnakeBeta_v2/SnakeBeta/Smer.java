
/**
 * Enumeration class Smer - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Smer {
    HORE,
    DOLE,
    DOLAVA,
    DOPRAVA;
    
    
    public static Smer otocDoprava(Smer input) {
        switch(input) {
            case DOLAVA:
                return DOLAVA;
            default:
                return DOPRAVA;
        }
    }
    
    public static Smer otocDolava(Smer input) {
        switch (input) {
            case DOPRAVA:
                return DOPRAVA;
            default:
                return DOLAVA;
        }
    }
    
    public static Smer otocHore(Smer input) {
        switch (input) {
            case DOLE:
                return DOLE;
            default:
                return HORE;
        }
    }
    
    public static Smer otocDole(Smer input) {
        switch (input) {
            case HORE:
                return HORE;
            default:
                return DOLE;
        }
    }
}

