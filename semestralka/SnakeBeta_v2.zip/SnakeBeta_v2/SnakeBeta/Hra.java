import java.util.Random;
import javax.swing.JOptionPane;
public class Hra {
    private Random generator;
    private int pocetTikov;
    private Ovladanie ovladanie;
    private Blok blok;
    private Manazer manazer;
    private Hadik hadik;
    private HraciaPlocha hraciaPlocha;
    private Smer smer;
    private Jablko jablko;
    private GrafickePocitadlo pocitadloSkore;
    public Hra() {
        this.pocitadloSkore = new GrafickePocitadlo(500, 80, 4);
        this.smer = Smer.DOPRAVA;
        this.manazer = new Manazer();
        this.generator = new Random();
        this.hraciaPlocha = new HraciaPlocha();
        this.hadik = new Hadik(this.hraciaPlocha.getSuradnice(), this.hraciaPlocha);
        this.ovladanie = new Ovladanie(this.hadik, this.smer, this);
        this.jablko = new Jablko(this.hraciaPlocha.getSuradnice(), this.hadik, this.hadik.getTelo());
        this.hadik.nakresli();
        this.pocetTikov = 0;
        this.pocitadloSkore.setHodnota(0);
        //this.hadik.vypisHada();
    }
    
    public boolean koliziaJablko() {
        if(this.hadik.getPolohuX() == this.jablko.getPolohuX() && this.hadik.getPolohuY() == this.jablko.getPolohuY()) {
            this.jablko.zmazJ();
            this.pocitadloSkore.zvys(10);
            this.hadik.zvacsiSa();
            this.jablko = new Jablko(this.hraciaPlocha.getSuradnice(), this.hadik, this.hadik.getTelo());
            return true;
        }
        return false; 
    }
    
    public void koliziaHranice() {
        if (this.hadik.getPolohuX() < 0 || this.hadik.getPolohuX() > 20 || this.hadik.getPolohuY() < 0 || this.hadik.getPolohuY() > 20) {
            JOptionPane.showMessageDialog(null, "Koniec hry");
            this.pocitadloSkore.setHodnota(0);
            System.exit(0);
        }
    }
}
