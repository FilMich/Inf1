
/**
 * Trieda Aplikacia spusta hru
 * 
 * @Filip Michalek
 * @version 1.0
 */
public class Aplikacia {
    public static void main (String[] args) {
        Hra hra = new Hra();
    }
}
