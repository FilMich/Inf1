
/**
 * Write a description of class Aplikacia here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Aplikacia {
    /**
     * Constructor for objects of class Aplikacia
     */
    public Aplikacia() {
        // initialise instance variables
    }
}
